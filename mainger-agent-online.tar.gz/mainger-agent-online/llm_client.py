"""
llm_client.py
-------------
Vendor-neutral wrapper around Anthropic and OpenAI tool-use APIs.

Both vendors support function calling but with slightly different shapes.
This module hides those differences behind a small interface:

    client = make_client(vendor, model)
    resp = client.complete(messages, tools, system)
    # resp = {"text": str | None, "tool_calls": [{"id","name","args"}, ...], "stop_reason": str}

    # to feed a tool result back:
    messages.append(client.format_tool_result(call_id, tool_name, result_dict))
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, Protocol


@dataclass
class LLMResponse:
    text: str | None
    tool_calls: list[dict[str, Any]]   # [{"id":..., "name":..., "args":...}]
    stop_reason: str
    raw: Any                           # full vendor response, for logging


class LLMClient(Protocol):
    def complete(self, messages, tools, system) -> LLMResponse: ...
    def format_assistant_with_tools(self, resp: LLMResponse) -> dict: ...
    def format_tool_result(self, call_id: str, tool_name: str, result: dict) -> dict: ...


# --------------------------------------------------------------------------- #
# Anthropic                                                                    #
# --------------------------------------------------------------------------- #
class AnthropicClient:
    def __init__(self, model: str, max_tokens: int, temperature: float):
        from anthropic import Anthropic
        self.client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature

    def complete(self, messages, tools, system) -> LLMResponse:
        resp = self.client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
            system=system,
            tools=tools,           # Anthropic-native schema
            messages=messages,
        )
        text_parts, tool_calls = [], []
        for block in resp.content:
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                tool_calls.append({"id": block.id, "name": block.name, "args": block.input})
        return LLMResponse(
            text="\n".join(text_parts) if text_parts else None,
            tool_calls=tool_calls,
            stop_reason=resp.stop_reason,
            raw=resp,
        )

    def format_assistant_with_tools(self, resp: LLMResponse) -> dict:
        """Echo the assistant turn back into the message history."""
        return {"role": "assistant", "content": resp.raw.content}

    def format_tool_result(self, call_id: str, tool_name: str, result: dict) -> dict:
        return {
            "role": "user",
            "content": [{
                "type": "tool_result",
                "tool_use_id": call_id,
                "content": json.dumps(result),
            }],
        }


# --------------------------------------------------------------------------- #
# OpenAI                                                                       #
# --------------------------------------------------------------------------- #
class OpenAIClient:
    def __init__(self, model: str, max_tokens: int, temperature: float):
        from openai import OpenAI
        self.client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature

    @staticmethod
    def _to_openai_tools(tools: list[dict]) -> list[dict]:
        # Convert {name, description, input_schema} -> OpenAI's nested shape
        return [{
            "type": "function",
            "function": {
                "name": t["name"],
                "description": t["description"],
                "parameters": t["input_schema"],
            },
        } for t in tools]

    def complete(self, messages, tools, system) -> LLMResponse:
        # OpenAI uses a system message in the messages list
        msgs = [{"role": "system", "content": system}] + messages
        resp = self.client.chat.completions.create(
            model=self.model,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
            tools=self._to_openai_tools(tools),
            messages=msgs,
        )
        msg = resp.choices[0].message
        tool_calls = []
        if msg.tool_calls:
            for c in msg.tool_calls:
                tool_calls.append({
                    "id": c.id,
                    "name": c.function.name,
                    "args": json.loads(c.function.arguments),
                })
        return LLMResponse(
            text=msg.content,
            tool_calls=tool_calls,
            stop_reason=resp.choices[0].finish_reason,
            raw=msg,
        )

    def format_assistant_with_tools(self, resp: LLMResponse) -> dict:
        return resp.raw.model_dump(exclude_none=True)

    def format_tool_result(self, call_id: str, tool_name: str, result: dict) -> dict:
        return {
            "role": "tool",
            "tool_call_id": call_id,
            "content": json.dumps(result),
        }


# --------------------------------------------------------------------------- #
# Factory                                                                      #
# --------------------------------------------------------------------------- #
def make_client(vendor: str, model: str, max_tokens: int = 4096, temperature: float = 0.0) -> LLMClient:
    vendor = vendor.lower()
    if vendor == "anthropic":
        return AnthropicClient(model, max_tokens, temperature)
    if vendor == "openai":
        return OpenAIClient(model, max_tokens, temperature)
    raise ValueError(f"Unknown vendor '{vendor}'. Supported: anthropic, openai.")
