"""
data_io.py
----------
Load user inputs (CSV, parquet, or manual summary entry) into a canonical
session dict and persist it as an RDS file that the R bridge reads.

Why RDS rather than JSON for the session itself: matrices like Sigma_int can
be hundreds of KB, and re-parsing them into R on every tool call is wasteful.
We serialize once at session start.
"""
from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import pandas as pd


def load_individual_csv(path: str | Path) -> dict[str, Any]:
    """Load individual-level (X, Y) data. First column = response."""
    df = pd.read_csv(path)
    y = df.iloc[:, 0].to_numpy()
    x = df.iloc[:, 1:].to_numpy()
    names = df.columns[1:].tolist()
    return {"X_int": x.tolist(), "Y_int": y.tolist(),
            "predictor_names": names, "n_int": len(y)}


def load_individual_parquet(path: str | Path) -> dict[str, Any]:
    df = pd.read_parquet(path)
    y = df.iloc[:, 0].to_numpy()
    x = df.iloc[:, 1:].to_numpy()
    names = df.columns[1:].tolist()
    return {"X_int": x.tolist(), "Y_int": y.tolist(),
            "predictor_names": names, "n_int": len(y)}


def load_external_coef_csv(path: str | Path) -> dict[str, Any]:
    """External coefficients as a 2-column CSV: variable, estimate."""
    df = pd.read_csv(path)
    if df.shape[1] < 2:
        raise ValueError("external coef CSV must have columns: variable, estimate")
    coef = dict(zip(df.iloc[:, 0].astype(str), df.iloc[:, 1].astype(float)))
    return {"beta_ext_named": coef}


def load_matrix_csv(path: str | Path) -> list[list[float]]:
    """Symmetric matrix CSV (no header by default; supply one if you have it)."""
    df = pd.read_csv(path, header=None)
    return df.to_numpy().tolist()


def align_external(beta_ext_named: dict[str, float], predictor_names: list[str]) -> list[float]:
    """Order external coefs to match internal predictor order; missing -> 0."""
    return [float(beta_ext_named.get(n, 0.0)) for n in predictor_names]


def build_session(
    *,
    internal_path: str | Path | None = None,
    internal_format: str = "csv",
    external_coef_path: str | Path | None = None,
    external_sigma_path: str | Path | None = None,
    reference_sigma_path: str | Path | None = None,
    sigma2_int: float | None = None,
    sigma2_ext: float | None = None,
    n_ext: int | None = None,
    manual: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Assemble a session dict from whatever the user has."""
    s: dict[str, Any] = {}
    if manual:
        s.update(manual)

    if internal_path:
        loader = {"csv": load_individual_csv, "parquet": load_individual_parquet}[internal_format]
        s.update(loader(internal_path))

    if external_coef_path:
        ext = load_external_coef_csv(external_coef_path)
        names = s.get("predictor_names")
        s["beta_ext"] = align_external(ext["beta_ext_named"], names) if names else list(ext["beta_ext_named"].values())

    if external_sigma_path:
        s["Sigma_ext"] = load_matrix_csv(external_sigma_path)
    if reference_sigma_path:
        s["Sigma_ref"] = load_matrix_csv(reference_sigma_path)

    if sigma2_int is not None: s["sigma2_int"] = sigma2_int
    if sigma2_ext is not None: s["sigma2_ext"] = sigma2_ext
    if n_ext      is not None: s["n_ext"]      = n_ext

    return s


def persist_session(session: dict[str, Any], out_dir: Path) -> dict[str, Any]:
    """Write the session as an RDS file the R bridge can read.

    Returns the session dict augmented with `_path` (the RDS location) and
    `_metadata` (a small dict suitable for showing to the LLM — sample sizes,
    dimensions, which fields are populated).
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / "session.json"
    rds_path  = out_dir / "session.rds"
    json_path.write_text(json.dumps(session))

    # Convert JSON -> RDS via a tiny inline R one-liner
    r_code = f"""
    library(jsonlite)
    s <- fromJSON('{json_path.as_posix()}', simplifyVector = TRUE)
    # Re-shape list-of-lists into proper matrices
    if (!is.null(s$X_int))     s$X_int     <- as.matrix(do.call(rbind, s$X_int))
    if (!is.null(s$Sigma_int)) s$Sigma_int <- as.matrix(do.call(rbind, s$Sigma_int))
    if (!is.null(s$Sigma_ext)) s$Sigma_ext <- as.matrix(do.call(rbind, s$Sigma_ext))
    if (!is.null(s$Sigma_ref)) s$Sigma_ref <- as.matrix(do.call(rbind, s$Sigma_ref))
    saveRDS(s, '{rds_path.as_posix()}')
    """
    proc = subprocess.run(["Rscript", "-e", r_code], capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(f"Failed to persist session as RDS:\n{proc.stderr}")

    session["_path"] = str(rds_path)
    session["_metadata"] = {
        "n_int": session.get("n_int"),
        "n_ext": session.get("n_ext"),
        "p":     len(session.get("predictor_names", [])) or None,
        "predictor_names": session.get("predictor_names"),
        "has_internal_individual_data": "X_int" in session and "Y_int" in session,
        "has_internal_marginal_only":   "r_int" in session and "X_int" not in session,
        "has_external_theta":           "beta_ext" in session,
        "has_external_sigma2":          "Sigma_ext" in session,
        "has_reference_panel":          "Sigma_ref" in session,
    }
    return session
