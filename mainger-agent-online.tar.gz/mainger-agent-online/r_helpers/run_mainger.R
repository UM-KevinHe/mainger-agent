#!/usr/bin/env Rscript
# r_helpers/run_mainger.R
# -----------------------
# JSON-in / JSON-out bridge between the Python agent and the mainger package.
#
# Protocol:
#   stdin  : {"tool": "<name>", "args": {...}, "session_path": "/tmp/.../session.rds"}
#   stdout : {"ok": true, "result": {...}}  OR  {"ok": false, "error": "<msg>"}
#
# The session RDS file is written once by data_io.py and contains the
# canonicalized data list (X_int, Y_int, beta_int, Sigma_int, beta_ext,
# Sigma_ext, sigma2_int, sigma2_ext, n_int, n_ext, predictor_names).

suppressPackageStartupMessages({
  # FILL IN: if mainger is installed in a non-default library path,
  # uncomment the next line and set the path.
  # .libPaths(c("/your/R/library/path", .libPaths()))
  library(mainger)
  library(jsonlite)
})

`%||%` <- function(a, b) if (is.null(a)) b else a

# --- Read request ---------------------------------------------------------- #
input <- paste(readLines("stdin", warn = FALSE), collapse = "\n")
req   <- fromJSON(input, simplifyVector = FALSE)
tool  <- req$tool
args  <- req$args
session <- if (file.exists(req$session_path)) readRDS(req$session_path) else list()

# --- Tool implementations -------------------------------------------------- #
detect_regime <- function(args, s) {
  has_int_ind <- isTRUE(args$has_internal_individual_data)
  has_int_marg <- isTRUE(args$has_internal_marginal_only)
  has_ext_theta <- isTRUE(args$has_external_theta)
  has_ext_sigma <- isTRUE(args$has_external_sigma2)
  has_ref       <- isTRUE(args$has_reference_panel)

  regime <- if (!has_ext_theta) {
    "none"
  } else if (has_int_ind && has_ext_sigma) {
    "full"
  } else if (has_int_ind) {
    "partial"
  } else if (has_int_marg && has_ref) {
    "restricted"
  } else {
    "indeterminate"
  }
  list(regime = regime,
       reason = sprintf("internal_indiv=%s, internal_marginal=%s, ext_theta=%s, ext_sigma2=%s, ref=%s",
                        has_int_ind, has_int_marg, has_ext_theta, has_ext_sigma, has_ref))
}

compute_eta_bound <- function(args, s) {
  regime <- args$regime
  if (regime == "partial") {
    eta_star <- mainger::eta_bound_partial(
      Sigma_int = s$Sigma_int, sigma2_int = s$sigma2_int, n_int = s$n_int,
      beta_int  = s$beta_int,  beta_ext   = s$beta_ext
    )
  } else if (regime == "full") {
    eta_star <- mainger::eta_bound_full(
      Sigma_int = s$Sigma_int, Sigma_ext = s$Sigma_ext,
      sigma2_int = s$sigma2_int, sigma2_ext = s$sigma2_ext,
      n_int = s$n_int, n_ext = s$n_ext,
      beta_int  = s$beta_int,  beta_ext  = s$beta_ext
    )
  } else if (regime == "restricted") {
    # Restricted regime currently uses the partial bound applied to the
    # padded/imputed estimator; see Section X of the paper.
    eta_star <- mainger::eta_bound_partial(
      Sigma_int = s$Sigma_ref, sigma2_int = s$sigma2_int, n_int = s$n_int,
      beta_int  = s$beta_int,  beta_ext   = s$beta_ext
    )
  } else {
    stop(sprintf("Unknown regime '%s'", regime))
  }
  list(eta_star = unname(eta_star), regime = regime)
}

check_concordance <- function(args, s) {
  eta <- args$eta
  db <- mainger::estimate_direction_biases(
    delta = s$beta_int - s$beta_ext,
    Sigma_int = s$Sigma_int, Sigma_ext = s$Sigma_ext,
    sigma2_ext = s$sigma2_ext, n_ext = s$n_ext
  )
  cc <- mainger::check_concordance(
    k_vals = db$k_vals, b_vals = db$b_vals,
    sigma2_int = s$sigma2_int, n_int = s$n_int, eta = eta
  )
  adv <- mainger::spectral_advantage(
    k_vals = db$k_vals, b_vals = db$b_vals,
    sigma2_int = s$sigma2_int, n_int = s$n_int, eta_grid = eta
  )
  list(eta = eta,
       verdict = cc$verdict %||% as.character(cc),
       advantage = unname(adv),
       k_vals = unname(db$k_vals),
       b_vals = unname(db$b_vals))
}

fit_integrated_estimator <- function(args, s) {
  fit_args <- list(
    X_int = s$X_int, Y_int = s$Y_int,
    beta_int = s$beta_int, Sigma_int = s$Sigma_int,
    r_int = s$r_int, Sigma_ref = s$Sigma_ref,
    beta_ext = s$beta_ext, Sigma_ext = s$Sigma_ext,
    sigma2_int = s$sigma2_int, sigma2_ext = s$sigma2_ext,
    n_int = s$n_int, n_ext = s$n_ext,
    tuning = args$tuning %||% "fixed",
    eta    = args$eta
  )
  fit_args <- fit_args[!vapply(fit_args, is.null, logical(1))]
  fit <- do.call(mainger::mainger, fit_args)

  list(
    regime    = args$regime,
    eta_used  = unname(fit$eta %||% args$eta),
    coef      = setNames(as.list(fit$coefficients),
                         s$predictor_names %||% paste0("x", seq_along(fit$coefficients))),
    mse_int   = unname(fit$mse_internal   %||% NA_real_),
    mse_intg  = unname(fit$mse_integrated %||% NA_real_),
    diag      = mainger::diagnose(fit, return_list = TRUE)
  )
}

# --- Dispatch -------------------------------------------------------------- #
out <- tryCatch({
  res <- switch(tool,
    detect_regime            = detect_regime(args, session),
    compute_eta_bound        = compute_eta_bound(args, session),
    check_concordance        = check_concordance(args, session),
    fit_integrated_estimator = fit_integrated_estimator(args, session),
    stop(sprintf("Unknown tool '%s'", tool))
  )
  list(ok = TRUE, result = res)
}, error = function(e) {
  list(ok = FALSE, error = conditionMessage(e))
})

cat(toJSON(out, auto_unbox = TRUE, null = "null", na = "null"))
