"""
agent.py
--------
Main orchestration loop and CLI entry point.

Pipeline
--------
  1. Parse CLI args, load config + .env.
  2. Build a session from the user's data files.
  3. Load the skill (system prompt) and templates.
  4. Run the tool-use loop:
       - LLM proposes tool calls
       - we dispatch them through the R bridge
       - results go back to the LLM
       - repeat until LLM emits a final JSON answer
  5. Render the three artifacts (report / code / explanation) from templates,
     write them + the full trace to the output directory.
"""
from __future__ import annotations

import argparse
import json
import os
import re
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv
from jinja2 import Environment, FileSystemLoader

from data_io import build_session, persist_session
from llm_client import LLMResponse, make_client
from tools import TOOL_SPECS, ToolError, call_tool

ROOT = Path(__file__).parent
SKILL_PATH    = ROOT / "skill.md"
TEMPLATE_DIR  = ROOT / "templates"


# --------------------------------------------------------------------------- #
# Skill & templates                                                            #
# --------------------------------------------------------------------------- #
def load_skill() -> str:
    return SKILL_PATH.read_text()


def render_artifacts(filled: dict[str, dict]) -> dict[str, str]:
    """Render report.md / analysis.R / explanation.md from Jinja templates."""
    env = Environment(loader=FileSystemLoader(TEMPLATE_DIR), keep_trailing_newline=True)
    return {
        "report.md":      env.get_template("report.md.j2").render(**filled.get("report", {})),
        "analysis.R":     env.get_template("code.R.j2").render(**filled.get("code", {})),
        "explanation.md": env.get_template("explanation.md.j2").render(**filled.get("explanation", {})),
    }


# --------------------------------------------------------------------------- #
# Final-answer parsing                                                         #
# --------------------------------------------------------------------------- #
FINAL_RE = re.compile(r"```json\s*(\{.*?\})\s*```", re.DOTALL)


def extract_final(text: str) -> dict | None:
    """Extract the JSON object containing report/code/explanation fields."""
    if not text:
        return None
    # Prefer fenced JSON; fall back to first top-level brace block
    m = FINAL_RE.search(text)
    candidate = m.group(1) if m else None
    if candidate is None:
        try:
            start = text.index("{")
            depth, end = 0, None
            for i, c in enumerate(text[start:], start=start):
                if c == "{": depth += 1
                elif c == "}":
                    depth -= 1
                    if depth == 0:
                        end = i + 1
                        break
            if end:
                candidate = text[start:end]
        except ValueError:
            return None
    try:
        obj = json.loads(candidate)
    except (json.JSONDecodeError, TypeError):
        return None
    if not isinstance(obj, dict) or not {"report", "code", "explanation"}.issubset(obj.keys()):
        return None
    return obj


# --------------------------------------------------------------------------- #
# Agent loop                                                                   #
# --------------------------------------------------------------------------- #
def run_agent(session: dict, user_message: str, cfg: dict) -> dict:
    client = make_client(
        vendor=cfg["vendor"], model=cfg["model"],
        max_tokens=cfg.get("max_tokens", 4096),
        temperature=cfg.get("temperature", 0.0),
    )
    skill = load_skill()
    system = (
        f"{skill}\n\n"
        f"Session metadata (read-only):\n{json.dumps(session['_metadata'], indent=2)}"
    )
    messages = [{"role": "user", "content": user_message}]
    trace = []

    for step in range(cfg.get("max_tool_iterations", 8)):
        resp: LLMResponse = client.complete(messages, TOOL_SPECS, system)
        trace.append({
            "step": step,
            "text": resp.text,
            "tool_calls": resp.tool_calls,
            "stop_reason": resp.stop_reason,
        })

        if not resp.tool_calls:
            final = extract_final(resp.text or "")
            if final is None:
                raise RuntimeError(
                    "LLM produced no tool calls and no parseable final JSON. "
                    f"Last text:\n{resp.text}"
                )
            return {"final": final, "trace": trace}

        # Echo the assistant turn (with its tool_use blocks) into history
        messages.append(client.format_assistant_with_tools(resp))

        # Dispatch each tool call
        for call in resp.tool_calls:
            try:
                bridge_out = call_tool(call["name"], call["args"], session)
                result = (bridge_out.get("result")
                          if bridge_out.get("ok")
                          else {"error": bridge_out.get("error")})
            except ToolError as e:
                result = {"error": str(e)}
            trace.append({"step": step, "tool_result": {"name": call["name"], "result": result}})
            messages.append(client.format_tool_result(call["id"], call["name"], result))

    raise RuntimeError(f"Hit max_tool_iterations={cfg['max_tool_iterations']} without final answer.")


# --------------------------------------------------------------------------- #
# CLI                                                                          #
# --------------------------------------------------------------------------- #
def main() -> None:
    load_dotenv()
    ap = argparse.ArgumentParser(description="mainger-agent (online)")
    ap.add_argument("--input", required=True, help="internal individual-data CSV/parquet")
    ap.add_argument("--input-format", default="csv", choices=["csv", "parquet"])
    ap.add_argument("--external-coef", required=True, help="external coefficients CSV (variable, estimate)")
    ap.add_argument("--external-sigma", help="external Sigma_2 CSV (full regime only)")
    ap.add_argument("--reference-sigma", help="reference panel Sigma_ref CSV (restricted regime only)")
    ap.add_argument("--sigma2-int", type=float)
    ap.add_argument("--sigma2-ext", type=float)
    ap.add_argument("--n-ext", type=int)
    ap.add_argument("--regime", choices=["full", "partial", "restricted"],
                    help="optional hint; the agent will detect it anyway")
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--out-dir", default="runs/latest")
    ap.add_argument("--message", default="Please analyze my data and produce the integration report, code, and explanation.")
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text())
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"[1/4] Loading data into session ...")
    session = build_session(
        internal_path=args.input,
        internal_format=args.input_format,
        external_coef_path=args.external_coef,
        external_sigma_path=args.external_sigma,
        reference_sigma_path=args.reference_sigma,
        sigma2_int=args.sigma2_int,
        sigma2_ext=args.sigma2_ext,
        n_ext=args.n_ext,
    )
    session = persist_session(session, out_dir)
    print(f"  metadata: {json.dumps(session['_metadata'])}")

    print(f"[2/4] Running agent (vendor={cfg['vendor']}, model={cfg['model']}) ...")
    user_msg = args.message
    if args.regime:
        user_msg += f"\n(I believe this is the {args.regime} regime.)"
    out = run_agent(session, user_msg, cfg)

    print(f"[3/4] Rendering artifacts ...")
    artifacts = render_artifacts(out["final"])

    print(f"[4/4] Writing outputs to {out_dir} ...")
    for name, content in artifacts.items():
        (out_dir / name).write_text(content)
    (out_dir / "trace.json").write_text(json.dumps(out["trace"], indent=2, default=str))
    (out_dir / "final.json").write_text(json.dumps(out["final"], indent=2))

    print("Done.")
    for name in ["report.md", "analysis.R", "explanation.md", "trace.json"]:
        print(f"  -> {out_dir / name}")


if __name__ == "__main__":
    main()
